package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.bean.TinhThanh;
import model.bo.TinhThanhBO;
import model.dao.TinhThanhDAO;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.DiaChiForm;
import form.QuanLyNhanVienForm;

public class DiaChiAction extends Action{
	private final static String SUCCESS = "success";
	   
    public ActionForward execute(ActionMapping mapping, ActionForm  form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {
       
        ArrayList<TinhThanh> tinhThanhs = new ArrayList();
        TinhThanhBO tinhThanhBO = new TinhThanhBO();
        tinhThanhs = tinhThanhBO.getTinhThanh();
        
    	
        DiaChiForm diaChiForm = (DiaChiForm) form;
        diaChiForm.setTinhThanhs(tinhThanhs);
        
        
        
       
        return mapping.findForward(SUCCESS);
       
    }
}
