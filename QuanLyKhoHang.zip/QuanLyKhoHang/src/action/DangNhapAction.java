package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.DangNhapForm;
import model.bean.TaiKhoan;
import model.bo.TaiKhoanBO;

public class DangNhapAction extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		DangNhapForm nguoiDungForm = (DangNhapForm) form;
		TaiKhoanBO taiKhoanBO = new TaiKhoanBO();
		TaiKhoan taiKhoan = taiKhoanBO.getTaiKhoan(nguoiDungForm.getTenDangNhap());
		String matKhau = taiKhoan.getMatKhau();
		if(matKhau.equals(nguoiDungForm.getMatKhau())){
			if("NV".equals(taiKhoan.getMaChucNang()))
				return mapping.findForward("trangNhanVien");
			else
				return mapping.findForward("trangAdmin");
		}
		else{
			return mapping.findForward("thatBai");
		}
	}
}
