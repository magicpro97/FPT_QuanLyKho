package action;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.NhanVien;
import model.bo.NhanVienBO;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.QuanLyNhanVienForm;

public class ChiTietNhanVienAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		QuanLyNhanVienForm quanLyNhanVienForm = (QuanLyNhanVienForm) form;	
		
		
		String maNV = request.getParameter("maNV");
//		PrintWriter out = response.getWriter();
//		out.write(maNV);
		NhanVienBO nhanVienBO = new NhanVienBO();
		if(maNV!=null){
			NhanVien nhanVien = nhanVienBO.getNhanVien(maNV);
			quanLyNhanVienForm.setNhanVien(nhanVien);
		
		System.out.println(maNV);
//		quanLyNhanVienForm.setAnhDaiDien(nhanVien.getAnhDaiDien());
//		quanLyNhanVienForm.setTenNV(nhanVien.getTenNV());
//		quanLyNhanVienForm.setGioiTinh(nhanVien.getGioiTinh());
//		quanLyNhanVienForm.setChucVu(nhanVien.getChucVu());
//		quanLyNhanVienForm.setDiaChi(nhanVien.getDiaChi());
//		quanLyNhanVienForm.setNgaySinh(nhanVien.getNgaySinh());
		}
		System.out.println("chitiet");
//		String submitXoa = quanLyNhanVienForm.getSubmitXoa();
//		if(submitXoa!=null){
//		
//			System.out.println("dang xoa"+maNV+"-->"+submitXoa);
//			nhanVienBO.deleteNhanVien(maNV);
//			response.sendRedirect("quanLiNhanVien.do");
//	
//		}
		
		

		return mapping.findForward("success");
		
		
	}
}
