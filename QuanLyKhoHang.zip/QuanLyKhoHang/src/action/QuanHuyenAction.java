package action;

import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.QuanHuyenForm;
import model.bean.QuanHuyen;
import model.bo.QuanHuyenBO;

public class QuanHuyenAction extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		QuanHuyenForm quanHuyenForm = (QuanHuyenForm) form;
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/text;charset=utf-8");
		response.setHeader("cache-control", "no-cache");
		QuanHuyenBO quanHuyenBO = new QuanHuyenBO();
		ArrayList<QuanHuyen> list = quanHuyenBO.getQuanHuyen(quanHuyenForm.getMaTT());
		System.out.println(quanHuyenForm.getMaTT());
		quanHuyenForm.setList(list);
		PrintWriter out = response.getWriter();
		out.println("<select id="+"'QuanHuyen'"+ "onchange="+"'doGetPhuongXa()'>");
		if(!list.isEmpty() && null!=list)
			for(QuanHuyen q : list)
				out.println("<option "+"value="+q.getMa()+">"+q.getTen()+"</option>");
		out.println("</select>");
		
		
		
		
		return null;
	}

}
