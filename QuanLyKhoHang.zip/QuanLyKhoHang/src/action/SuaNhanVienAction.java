package action;

import java.sql.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.NhanVien;
import model.bo.NhanVienBO;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.NhanVienForm;

public class SuaNhanVienAction extends Action{
	private final static String SUCCESS = "success";
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		
		NhanVienForm nhanVienForm = (NhanVienForm) form;
		NhanVienBO nhanVienBO = new NhanVienBO();
		//dua thong tin len form
		
		String maNV = request.getParameter("maNV");
		if(maNV!=null){
			NhanVien nhanVien = nhanVienBO.getNhanVien(maNV);
			nhanVienForm.setAnhDaiDien(nhanVien.getAnhDaiDien());
			nhanVienForm.setTenNV(nhanVien.getTenNV());
			nhanVienForm.setGioiTinh(nhanVien.getGioiTinh());
			nhanVienForm.setChucVu(nhanVien.getChucVu());
	//		nhanVienForm.setDiaChi(nhanVien.getDiaChi());
			nhanVienForm.setNgaySinh(nhanVien.getNgaySinh());
		}
		
		
		//thay doi--> nhan submit-->luu
		String suaSubmit = request.getParameter("suaSubmit");
		if(suaSubmit!=null){
			String tenNV = request.getParameter("tenNV");
			String anhDaiDien = request.getParameter("anhDaiDien");
			String gioiTinh = request.getParameter("gioiTinh");
			String chucVu = request.getParameter("chucVu");
			String ngaySinh = request.getParameter("ngaySinh");
			Date date = Date.valueOf(ngaySinh);
			System.out.println(date);
			
			NhanVien nhanVien = new NhanVien(maNV, tenNV, anhDaiDien, chucVu, date, gioiTinh, "diachi", "soDienThoai", "email");
			nhanVienBO.updateNhanVien(nhanVien);
			
		}
		
		
		
		 return mapping.findForward(SUCCESS);
		}

}
