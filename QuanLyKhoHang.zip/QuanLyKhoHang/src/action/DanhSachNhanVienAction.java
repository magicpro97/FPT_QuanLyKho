package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.NhanVien;
import model.bo.NhanVienBO;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.QuanLyNhanVienForm;

public class DanhSachNhanVienAction extends Action{
	public ActionForward execute(ActionMapping mapping,ActionForm form,
			HttpServletRequest request,HttpServletResponse response)
	        throws Exception {
			QuanLyNhanVienForm quanLyNhanVienForm = (QuanLyNhanVienForm) form;	
			NhanVienBO nhanVienBO = new NhanVienBO();
			ArrayList<NhanVien> nhanVienArrays = nhanVienBO.getListNhanVien();
			quanLyNhanVienForm.setNhanViens(nhanVienArrays);

			return mapping.findForward("success");
		}

		
	
}
