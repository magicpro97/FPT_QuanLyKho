package action;

import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.PhuongXaForm;
import model.bean.PhuongXa;
import model.bo.PhuongXaBO;

public class PhuongXaAction extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		PhuongXaForm phuongXaForm = (PhuongXaForm) form;
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/text;charset=utf-8");
		response.setHeader("cache-control", "no-cache");
		PhuongXaBO phuongXaBO = new PhuongXaBO();
		ArrayList<PhuongXa> list = phuongXaBO.getPhuongXa("1");
		System.out.println(phuongXaForm.getMaQH());
		phuongXaForm.setList(list);
		PrintWriter out = response.getWriter();
		out.println("<select id="+"'tinhPhuongXa'"+ "onchange="+"'doGetPhuongXa()'>");
		for(PhuongXa p : list)
			out.println("<option "+"value="+p.getMa()+">"+p.getTen()+"</option>");
		out.println("</select>");
		return null;
	}
	
}
