package model.bean;

public class TaiKhoan {
	String tenDangNhap;
	String matKhau;
	String maChucNang;
	
	public TaiKhoan() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TaiKhoan(String tenDangNhap, String matKhau, String maChucNang) {
		super();
		this.tenDangNhap = tenDangNhap;
		this.matKhau = matKhau;
		this.maChucNang = maChucNang;
	}
	public String getTenDangNhap() {
		return tenDangNhap;
	}
	public void setTenDangNhap(String tenDangNhap) {
		this.tenDangNhap = tenDangNhap;
	}
	public String getMatKhau() {
		return matKhau;
	}
	public void setMatKhau(String matKhau) {
		this.matKhau = matKhau;
	}
	public String getMaChucNang() {
		return maChucNang;
	}
	public void setMaChucNang(String maChucNang) {
		this.maChucNang = maChucNang;
	}
}
