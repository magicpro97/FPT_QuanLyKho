package model.bo;

import java.util.ArrayList;

import model.bean.PhuongXa;
import model.dao.PhuongXaDAO;

public class PhuongXaBO {
	PhuongXaDAO phuongXaDAO = new PhuongXaDAO();

	public ArrayList<PhuongXa> getPhuongXa(String maQH) {
		return phuongXaDAO.getPhuongXa(maQH);
	}

	
	

}
