package model.bo;

import java.util.ArrayList;

import model.bean.NhanVien;
import model.dao.NhanVienDAO;

public class NhanVienBO {
	NhanVienDAO nhanVienDAO = new NhanVienDAO();

	public boolean insertNhanVien(NhanVien nhanVien) {
		return nhanVienDAO.insertNhanVien(nhanVien);
	}

	public ArrayList<NhanVien> getListNhanVien() {
		return nhanVienDAO.getListNhanVien();
	}
	
	public NhanVien getNhanVien(String maNV){
		return nhanVienDAO.getNhanVien(maNV);
	}
	
	public boolean deleteNhanVien(String maNV){
		return nhanVienDAO.deleteNhanVien(maNV);
	}
	
	public boolean updateNhanVien(NhanVien nhanVien){
		return nhanVienDAO.updateNhanVien(nhanVien);
	}
}
