package model.bo;

import java.util.ArrayList;

import model.bean.TinhThanh;
import model.dao.TinhThanhDAO;

public class TinhThanhBO {
	TinhThanhDAO tinhThanhDAO = new TinhThanhDAO();

	public ArrayList<TinhThanh> getTinhThanh(){
		return tinhThanhDAO.getTinhThanh();
	}
	

}
