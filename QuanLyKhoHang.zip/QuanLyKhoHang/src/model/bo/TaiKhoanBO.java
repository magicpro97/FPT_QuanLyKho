package model.bo;

import model.bean.TaiKhoan;
import model.dao.TaiKhoanDAO;

public class TaiKhoanBO {
	TaiKhoanDAO taiKhoanDAO = new TaiKhoanDAO();
	
	public String getMatKhau(String tenDangNhap) {
		return taiKhoanDAO.getMatKhau(tenDangNhap);
	}

	public TaiKhoan getTaiKhoan(String tenDangNhap) {
		return taiKhoanDAO.getTaiKhoan(tenDangNhap);
	}

}
