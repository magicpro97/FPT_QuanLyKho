package model.bo;

import java.util.ArrayList;

import model.bean.QuanHuyen;
import model.dao.QuanHuyenDAO;

public class QuanHuyenBO {
	QuanHuyenDAO quanHuyenDAO = new QuanHuyenDAO();
	

	public ArrayList<QuanHuyen> getQuanHuyen(String maQuanHuyen){
		return quanHuyenDAO.getQuanHuyen(maQuanHuyen);
	}
	

}
