package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import model.bean.PhuongXa;
import ultis.ConnectDB;

public class PhuongXaDAO {
	private Connection con = null;
	private ConnectDB connectDB;

	public PhuongXaDAO() {
		connectDB = new ConnectDB();
		con = connectDB.getConnection();
	}
	
	public ArrayList<PhuongXa> getPhuongXa(String maQH){
		ArrayList<PhuongXa> list = new ArrayList<>();
		
		try {
			String sql = "select maPX,ten  from PhuongXa where maQH=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, maQH);
			ResultSet rs = ps.executeQuery();
			
			
			
			while(rs.next()){
				String ma = rs.getString(1);
				String ten = rs.getString(2);
				
				PhuongXa PhuongXa = new PhuongXa(ma, ten);
				list.add(PhuongXa);
			}
			
		} catch (Exception e) {
			System.out.println("loi lay danh sach Phuong Xa" + e.getMessage());
		}
		return list;
	}
	public static void main(String[] args) {
		System.out.println(new PhuongXaDAO().getPhuongXa("1"));
	}
}
