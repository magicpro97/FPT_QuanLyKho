package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import model.bean.TinhThanh;
import ultis.ConnectDB;

public class TinhThanhDAO {
	private Connection con = null;
	private ConnectDB connectDB;

	public TinhThanhDAO() {
		connectDB = new ConnectDB();
		con = connectDB.getConnection();
	}
	
	public ArrayList<TinhThanh> getTinhThanh(){
		ArrayList<TinhThanh> list = new ArrayList<>();
		
		try {
			String sql = "select *  from TinhThanh";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				String ma = rs.getString(1);
				String ten = rs.getString(2);
				
				TinhThanh tinhThanh = new TinhThanh(ma, ten);
				list.add(tinhThanh);
			}
			
		} catch (Exception e) {
			System.out.println("loi lay danh sach tinh thanh" + e.getMessage());
		}
		return list;
	}
	
	
	public ArrayList<String> getTenTinhThanh(){
		ArrayList<String> list = new ArrayList<>();
		
		try {
			String sql = "select ten  from TinhThanh";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				
				String ten = rs.getString(1);
				
				list.add(ten);
			}
			
		} catch (Exception e) {
			System.out.println("loi lay danh sach tinh thanh" + e.getMessage());
		}
		return list;
	}
	
	public static void main(String[] args) {
		TinhThanhDAO tinhThanhDAO = new TinhThanhDAO();
		System.out.println(tinhThanhDAO.getTinhThanh().get(0).getTen());
		
		
		System.out.println(tinhThanhDAO.getTenTinhThanh());
	}
}
