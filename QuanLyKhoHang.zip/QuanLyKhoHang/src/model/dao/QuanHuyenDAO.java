package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import model.bean.QuanHuyen;
import ultis.ConnectDB;

public class QuanHuyenDAO {
	private Connection con = null;
	private ConnectDB connectDB;

	public QuanHuyenDAO() {
		connectDB = new ConnectDB();
		con = connectDB.getConnection();
	}
	
	public ArrayList<QuanHuyen> getQuanHuyen(String maTT){
		ArrayList<QuanHuyen> list = new ArrayList<>();
		
		try {
			String sql = "select *  from QuanHuyen where maTThanh=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, maTT);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				String ma = rs.getString(1);
				String ten = rs.getString(2);
				
				QuanHuyen QuanHuyen = new QuanHuyen(ma, ten);
				list.add(QuanHuyen);
			}
			
		} catch (Exception e) {
			System.out.println("loi lay danh sach quan huyen" + e.getMessage());
		}
		return list;
	}
	public static void main(String[] args) {
		System.out.println(new QuanHuyenDAO().getQuanHuyen("1"));
	}	
}
