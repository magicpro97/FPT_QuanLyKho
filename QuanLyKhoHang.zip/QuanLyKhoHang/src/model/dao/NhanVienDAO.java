package model.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import model.bean.NhanVien;
import model.bean.PhuongXa;
import model.bo.NhanVienBO;
import ultis.ConnectDB;

public class NhanVienDAO {
	private Connection con = null;
	private ConnectDB connectDB;

	public NhanVienDAO() {
		connectDB = new ConnectDB();
		con = connectDB.getConnection();
	}
	
	
	public boolean insertNhanVien(NhanVien nhanVien){
		boolean isSucess = false;
		
		try {
			String sql = "insert into NHANVIEN(TenNV, ChucVu,NgaySinh,GioiTinh,DiaChi,AnhDaiDien) "+
						"values (?,?,?,?,?,?)";
			
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1,nhanVien.getTenNV() );
			ps.setString(2, nhanVien.getChucVu());
			ps.setDate(3, nhanVien.getNgaySinh());
			ps.setString(4, nhanVien.getGioiTinh());
			ps.setString(5, nhanVien.getDiaChi());
			ps.setString(6, nhanVien.getAnhDaiDien());
//			ps.setString(6, nhanVien.getSoDienThoai());
//			ps.setString(7, nhanVien.getEmail());
			
			isSucess = ps.executeUpdate()>0;
			System.out.println("da them thanh cong");
		} catch (Exception e) {
			System.out.println("loi : insert NhanVien \n"+ e.getMessage());
		}
		
		
		return isSucess;
	}
	public ArrayList<NhanVien> getListNhanVien(){
		ArrayList<NhanVien> list = new ArrayList<>();
		
		try {
			String sql = "select MaNV,TenNV,	ChucVu, NgaySinh,GioiTinh,DiaChi,AnhDaiDien "+
						"from NHANVIEN";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				String maNV = rs.getString(1);
				String tenNV = rs.getString(2);
				String chucVu = rs.getString(3);
				Date date = rs.getDate(4);
				String gioiTinh = rs.getString(5);
				String diaChi = rs.getString(6);
				String anhDaiDien = rs.getString(7);
				
				
				NhanVien nhanVien = new NhanVien(maNV, tenNV, anhDaiDien, chucVu, date, gioiTinh, diaChi, null, null);
				list.add(nhanVien);
			}
			
		} catch (Exception e) {
			System.out.println("loi lay danh sach NhanVien" + e.getMessage());
		}
		return list;
	}
	
	
	
	public NhanVien getNhanVien(String maNV){
		NhanVien nhanVien = null;
		
		try {
			String sql = "select MaNV,TenNV,	ChucVu, NgaySinh,GioiTinh,DiaChi,AnhDaiDien "+
						"from NHANVIEN"
						+ " where maNV=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, maNV);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				
				String tenNV = rs.getString(2);
				String chucVu = rs.getString(3);
				Date date = rs.getDate(4);
				String gioiTinh = rs.getString(5);
				String diaChi = rs.getString(6);
				String anhDaiDien = rs.getString(7);
				
				
				nhanVien = new NhanVien(maNV, tenNV, anhDaiDien, chucVu, date, gioiTinh, diaChi, null, null);
				
			}
			
		} catch (Exception e) {
			System.out.println("loi lay thong tin  nhanVien" + e.getMessage());
		}
		return nhanVien;
	}
	
	public boolean deleteNhanVien(String maNV){
		boolean isSucess = false;
		
		try {
			String sql = " delete from NhanVien where MaNV =?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, maNV);

			isSucess = ps.executeUpdate()>0;
			System.out.println("da them thanh cong");
		} catch (Exception e) {
			System.out.println("loi : insert NhanVien \n"+ e.getMessage());
		}
		
		
		return isSucess;
	}
	
	public boolean updateNhanVien(NhanVien nhanVien){
		boolean isSucess = false;
		
		try {
			String sql = " update NhanVien "+
						"set tenNV=?,chucVu=?, ngaySinh=?,gioiTinh=?,anhDaiDien=?,DiaChi=?,soDT=?,email=? "
						+"where maNV=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, nhanVien.getTenNV());
			ps.setString(2, nhanVien.getChucVu());
			ps.setDate(3, nhanVien.getNgaySinh());
			ps.setString(4, nhanVien.getGioiTinh());
			ps.setString(5, nhanVien.getAnhDaiDien());
			ps.setString(6, nhanVien.getDiaChi());
			ps.setString(7, nhanVien.getSoDienThoai());
			ps.setString(8, nhanVien.getEmail());
			ps.setString(9, nhanVien.getMaNV());
			System.out.println(sql);
			isSucess = ps.executeUpdate()>0;
			System.out.println("da sua thanh cong");
		} catch (Exception e) {
			System.out.println("loi : insert NhanVien \n"+ e.getMessage());
		}
		
		
		return isSucess;
	}
	
	public static void main(String[] args) {
		Date date = new Date(1111);
		NhanVien nhanVien = new NhanVien(null,"aaa","bb", "a", date, "0", "a",null,null);
		
		
		NhanVienDAO nhanVienDAO = new NhanVienDAO();
		nhanVienDAO.insertNhanVien(nhanVien);
		
//		System.out.println(new NhanVienBO().deleteNhanVien("7"));
//		System.out.println( new NhanVienBO().getListNhanVien().get(0).getTenNV());
//		System.out.println(new NhanVienBO().getNhanVien("6").getTenNV() );
	}
}
