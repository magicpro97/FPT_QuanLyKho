package form;

import java.sql.Date;
import java.util.ArrayList;

import model.bean.PhuongXa;
import model.bean.QuanHuyen;
import model.bean.TinhThanh;
import model.bo.TinhThanhBO;

import org.apache.struts.action.ActionForm;

public class NhanVienForm extends ActionForm{
	private String maNV;
	private String tenNV;
	private String anhDaiDien;
	private String chucVu;
	private Date ngaySinh;
	private String gioiTinh;
	
	private String duong;
	private TinhThanh thanhPho;
	private QuanHuyen quan;
	private PhuongXa phuong;
	
	private String submit;
	public String getTenNV() {
		return tenNV;
	}
	
	
	public String getMaNV() {
		return maNV;
	}


	public void setMaNV(String maNV) {
		this.maNV = maNV;
	}


	public void setTenNV(String tenNV) {
		this.tenNV = tenNV;
	}
	public String getAnhDaiDien() {
		return anhDaiDien;
	}
	public void setAnhDaiDien(String anhDaiDien) {
		this.anhDaiDien = anhDaiDien;
	}
	public String getChucVu() {
		return chucVu;
	}
	public void setChucVu(String chucVu) {
		this.chucVu = chucVu;
	}
	public Date getNgaySinh() {
		return ngaySinh;
	}
	public void setNgaySinh(Date ngaySinh) {
		this.ngaySinh = ngaySinh;
	}
	public String getGioiTinh() {
		return gioiTinh;
	}
	public void setGioiTinh(String gioiTinh) {
		this.gioiTinh = gioiTinh;
	}
	
	public String getDuong() {
		return duong;
	}
	public void setDuong(String duong) {
		this.duong = duong;
	}
	
	public TinhThanh getThanhPho() {
		return thanhPho;
	}
	public void setThanhPho(TinhThanh thanhPho) {
		this.thanhPho = thanhPho;
	}
	public QuanHuyen getQuan() {
		return quan;
	}
	public void setQuan(QuanHuyen quan) {
		this.quan = quan;
	}
	public PhuongXa getPhuong() {
		return phuong;
	}
	public void setPhuong(PhuongXa phuong) {
		this.phuong = phuong;
	}
	public String getSubmit() {
		return submit;
	}
	public void setSubmit(String submit) {
		this.submit = submit;
	}
	
	
	
	
	

}
