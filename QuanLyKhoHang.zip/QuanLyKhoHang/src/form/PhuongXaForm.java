package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import model.bean.PhuongXa;

public class PhuongXaForm extends ActionForm{
	ArrayList<PhuongXa> list = new ArrayList<>();
	private String maQH;

	public ArrayList<PhuongXa> getList() {
		return list;
	}

	public void setList(ArrayList<PhuongXa> list) {
		this.list = list;
	}

	public String getMaQH() {
		return maQH;
	}

	public void setMaQH(String maQH) {
		this.maQH = maQH;
	}
	
	
	
}
