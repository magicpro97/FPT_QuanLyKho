package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import model.bean.QuanHuyen;
import model.bean.TinhThanh;

public class DiaChiForm extends ActionForm{
	TinhThanh tinhThanh;
	QuanHuyen quanHuyen;
	
	ArrayList<TinhThanh> tinhThanhs;
	public TinhThanh getTinhThanh() {
		return tinhThanh;
	}
	public void setTinhThanh(TinhThanh tinhThanh) {
		this.tinhThanh = tinhThanh;
	}
	public QuanHuyen getQuanHuyen() {
		return quanHuyen;
	}
	public void setQuanHuyen(QuanHuyen quanHuyen) {
		this.quanHuyen = quanHuyen;
	}
	public ArrayList<TinhThanh> getTinhThanhs() {
		return tinhThanhs;
	}
	public void setTinhThanhs(ArrayList<TinhThanh> tinhThanhs) {
		this.tinhThanhs = tinhThanhs;
	}
	
	
}
