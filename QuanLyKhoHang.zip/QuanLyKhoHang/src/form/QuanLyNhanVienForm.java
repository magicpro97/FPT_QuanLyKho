package form;

import java.sql.Date;
import java.util.ArrayList;

import model.bean.NhanVien;
import model.bo.NhanVienBO;

import org.apache.struts.action.ActionForm;

public class QuanLyNhanVienForm extends ActionForm{
	NhanVienBO nhanVienBO = new NhanVienBO();
	ArrayList<NhanVien> nhanViens;
	NhanVien nhanVien;
	
	private String submitXoa;
	
	
//	String maNV;
//	String tenNV;
//	private String anhDaiDien;
//	private String chucVu;
//	private Date ngaySinh;
//	private String gioiTinh;
//	
//	private String diaChi;
//	private String soDienThoai;
//	private String email;
	
	
	public ArrayList<NhanVien> getNhanViens() {
		return nhanViens;
	}
	public void setNhanViens(ArrayList<NhanVien> nhanViens) {
		this.nhanViens = nhanViens;
	}
	public NhanVienBO getNhanVienBO() {
		return nhanVienBO;
	}
	public void setNhanVienBO(NhanVienBO nhanVienBO) {
		this.nhanVienBO = nhanVienBO;
	}
	public NhanVien getNhanVien() {
		return nhanVien;
	}
	public void setNhanVien(NhanVien nhanVien) {
		this.nhanVien = nhanVien;
	}
	
	public String getSubmitXoa() {
		return submitXoa;
	}
	public void setSubmitXoa(String submitXoa) {
		this.submitXoa = submitXoa;
	}
	
	
	
//	public String getMaNV() {
//		return maNV;
//	}
//	public void setMaNV(String maNV) {
//		this.maNV = maNV;
//	}
//	public String getTenNV() {
//		return tenNV;
//	}
//	public void setTenNV(String tenNV) {
//		this.tenNV = tenNV;
//	}
//	public String getAnhDaiDien() {
//		return anhDaiDien;
//	}
//	public void setAnhDaiDien(String anhDaiDien) {
//		this.anhDaiDien = anhDaiDien;
//	}
//	public String getChucVu() {
//		return chucVu;
//	}
//	public void setChucVu(String chucVu) {
//		this.chucVu = chucVu;
//	}
//	public Date getNgaySinh() {
//		return ngaySinh;
//	}
//	public void setNgaySinh(Date ngaySinh) {
//		this.ngaySinh = ngaySinh;
//	}
//	public String getGioiTinh() {
//		return gioiTinh;
//	}
//	public void setGioiTinh(String gioiTinh) {
//		this.gioiTinh = gioiTinh;
//	}
//	public String getDiaChi() {
//		return diaChi;
//	}
//	public void setDiaChi(String diaChi) {
//		this.diaChi = diaChi;
//	}
//	public String getSoDienThoai() {
//		return soDienThoai;
//	}
//	public void setSoDienThoai(String soDienThoai) {
//		this.soDienThoai = soDienThoai;
//	}
//	public String getEmail() {
//		return email;
//	}
//	public void setEmail(String email) {
//		this.email = email;
//	}
//	
	
	

}
