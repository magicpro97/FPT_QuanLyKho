package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import model.bean.QuanHuyen;

public class QuanHuyenForm extends ActionForm{
	private ArrayList<QuanHuyen> list = new ArrayList<>();
	private String maTT;
	
	
	public String getMaTT() {
		return maTT;
	}

	public void setMaTT(String maTT) {
		this.maTT = maTT;
	}

	public ArrayList<QuanHuyen> getList() {
		return list;
	}

	public void setList(ArrayList<QuanHuyen> list) {
		this.list = list;
	}
}
